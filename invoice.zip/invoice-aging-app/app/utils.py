from datetime import date

def days_overdue(due_date: date, today: date) -> int:
    return (today - due_date).days

def compute_aging_bucket(due_date: date, today: date) -> str | None:
    """Return aging bucket for overdue amounts only.
    Buckets: '0–30', '31–60', '61–90', '90+'.
    If not overdue (today <= due_date), return None.
    """
    d = days_overdue(due_date, today)
    if d <= 0:
        return None
    if 1 <= d <= 30:
        return "0–30"
    if 31 <= d <= 60:
        return "31–60"
    if 61 <= d <= 90:
        return "61–90"
    return "90+"
