import os
from datetime import date
import pandas as pd
import streamlit as st

from db import query, execute
from utils import compute_aging_bucket
import queries as q

st.set_page_config(page_title="Invoice Aging & Payments", layout="wide")

st.title("Invoice Aging & Payments")

# Sidebar filters
with st.sidebar:
    st.header("Filters")
    # Fetch customers
    customers = query("SELECT customer_id, name FROM customers ORDER BY name;")
    customer_map = {c["name"]: c["customer_id"] for c in customers}
    customer_choice = st.selectbox("Customer", ["All"] + list(customer_map.keys()))
    customer_id = customer_map.get(customer_choice) if customer_choice != "All" else None

    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Start invoice date", value=None)
    with col2:
        end_date = st.date_input("End invoice date", value=None)

params = {
    "customer_id": customer_id,
    "start_date": start_date.isoformat() if start_date else None,
    "end_date": end_date.isoformat() if end_date else None,
}

rows = query(q.LIST_INVOICES, params)
df = pd.DataFrame(rows)

today = date.today()

if not df.empty:
    # Derived columns
    df["total_paid"] = df["total_paid"].astype(float)
    df["outstanding"] = df["outstanding"].astype(float)
    df["aging_bucket"] = df.apply(
        lambda r: compute_aging_bucket(r["due_date"], today) if r["outstanding"] > 0 else None,
        axis=1,
    )
else:
    df = pd.DataFrame(columns=[
        "invoice_id","customer_name","invoice_date","due_date","amount","total_paid","outstanding","aging_bucket"
    ])

# KPIs
total_invoiced = float(df["amount"].sum()) if not df.empty else 0.0
total_received = float(df["total_paid"].sum()) if not df.empty else 0.0
total_outstanding = float(df["outstanding"].sum()) if not df.empty else 0.0
overdue_outstanding = float(df.loc[df["aging_bucket"].notna(), "outstanding"].sum()) if not df.empty else 0.0
percent_overdue = (overdue_outstanding / total_outstanding * 100.0) if total_outstanding > 0 else 0.0

k1, k2, k3, k4 = st.columns(4)
k1.metric("Total Invoiced", f"{total_invoiced:,.2f}")
k2.metric("Total Received", f"{total_received:,.2f}")
k3.metric("Total Outstanding", f"{total_outstanding:,.2f}")
k4.metric("% Overdue", f"{percent_overdue:.1f}%")

st.subheader("Invoices")

# Simple search on customer name
search = st.text_input("Search by customer name")
to_show = df
if search:
    to_show = to_show[to_show["customer_name"].str.contains(search, case=False, na=False)]

# Highlight overdue rows
def highlight_overdue(row):
    return ["background-color: #ffe6e6" if row.get("aging_bucket") else "" for _ in row]

st.dataframe(
    to_show.style.apply(highlight_overdue, axis=1),
    use_container_width=True,
    height=420,
)

# Record payment form
st.subheader("Record Payment")
col_a, col_b, col_c = st.columns([2,1,1])
with col_a:
    inv_id = st.number_input("Invoice ID", min_value=1, step=1, format="%d")
with col_b:
    pay_amount = st.number_input("Amount", min_value=0.01, step=0.01, format="%.2f")
with col_c:
    pay_date = st.date_input("Payment Date", value=today)

if st.button("Submit Payment", use_container_width=False):
    # Validate outstanding before insert
    inv_lookup = df[df["invoice_id"] == inv_id]
    if inv_lookup.empty:
        st.error("Invoice not found in current filter. Clear filters or check ID.")
    else:
        outstanding = float(inv_lookup["outstanding"].iloc[0])
        if pay_amount <= 0:
            st.error("Amount must be positive.")
        elif pay_amount > outstanding:
            st.error(f"Amount exceeds outstanding ({outstanding:,.2f}).")
        else:
            execute(
                """INSERT INTO payments (invoice_id, payment_date, amount)
                VALUES (:invoice_id, :payment_date, :amount)""",
                {
                    "invoice_id": int(inv_id),
                    "payment_date": pay_date.isoformat(),
                    "amount": float(pay_amount),
                },
            )
            st.success("Payment recorded.")
            st.rerun()


# Chart: Top 5 customers by outstanding
st.subheader("Top 5 Customers by Outstanding")
top5 = query(q.TOP5_OUTSTANDING, {})
top5_df = pd.DataFrame(top5)
if not top5_df.empty:
    top5_df["total_outstanding"] = top5_df["total_outstanding"].astype(float)
    st.bar_chart(top5_df.set_index("name")["total_outstanding"])
else:
    st.info("No outstanding balances found.")
