# Parameterized SQL only
LIST_INVOICES = """
SELECT
  i.invoice_id,
  c.name AS customer_name,
  i.invoice_date,
  i.due_date,
  i.amount,
  COALESCE(SUM(p.amount), 0) AS total_paid,
  (i.amount - COALESCE(SUM(p.amount), 0)) AS outstanding
FROM invoices i
JOIN customers c ON c.customer_id = i.customer_id
LEFT JOIN payments p ON p.invoice_id = i.invoice_id
WHERE
  (:customer_id IS NULL OR i.customer_id = :customer_id)
  AND (:start_date IS NULL OR i.invoice_date >= :start_date)
  AND (:end_date   IS NULL OR i.invoice_date <= :end_date)
GROUP BY i.invoice_id, c.name, i.invoice_date, i.due_date, i.amount
ORDER BY i.invoice_date DESC;
"""

ADD_PAYMENT = """
INSERT INTO payments (invoice_id, payment_date, amount)
VALUES (:invoice_id, :payment_date, :amount);
"""

TOP5_OUTSTANDING = """
WITH paid AS (
  SELECT invoice_id, COALESCE(SUM(amount),0) AS total_paid
  FROM payments
  GROUP BY invoice_id
)
SELECT
  c.customer_id,
  c.name,
  SUM(i.amount - COALESCE(p.total_paid,0)) AS total_outstanding
FROM invoices i
JOIN customers c ON c.customer_id = i.customer_id
LEFT JOIN paid p ON p.invoice_id = i.invoice_id
GROUP BY c.customer_id, c.name
HAVING SUM(i.amount - COALESCE(p.total_paid,0)) > 0
ORDER BY total_outstanding DESC
LIMIT 5;
"""
