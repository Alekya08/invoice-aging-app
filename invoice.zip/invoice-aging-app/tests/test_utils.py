from datetime import date
from app.utils import compute_aging_bucket

def test_not_overdue_returns_none():
    today = date(2025, 8, 22)
    assert compute_aging_bucket(date(2025, 8, 22), today) is None
    assert compute_aging_bucket(date(2025, 8, 23), today) is None

def test_0_30_bucket():
    today = date(2025, 8, 22)
    assert compute_aging_bucket(date(2025, 8, 21), today) == "0–30"
    assert compute_aging_bucket(date(2025, 7, 27), today) == "0–30"

def test_31_60_bucket():
    today = date(2025, 8, 22)
    assert compute_aging_bucket(date(2025, 7, 22), today) == "31–60"
    assert compute_aging_bucket(date(2025, 6, 24), today) == "31–60"

def test_61_90_bucket():
    today = date(2025, 8, 22)
    assert compute_aging_bucket(date(2025, 6, 22), today) == "61–90"
    assert compute_aging_bucket(date(2025, 5, 24), today) == "61–90"

def test_90_plus_bucket():
    today = date(2025, 8, 22)
    assert compute_aging_bucket(date(2025, 5, 22), today) == "90+"
